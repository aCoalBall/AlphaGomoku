import random
import copy
import math
import os
import torch
import numpy

import GomokuNet
from gomoku import *
from BoardForMCTS import Board
from GomokuNet import NeuralNetwork
from GomokuNet import NET

BLACK = 1
WHITE = 2
STATUS = 0
WINNING_RATE = 1
ALL_MOVES = 2


class MonteCarlo :

    def __init__(self) :
        self.current_state = Board()
        #total exploration times
        self.total_attempts = 1
        #for each state, record its status, and its winning rate 
        # in the form (status, [win, all])
        self.states_dic = {}
        #add the root state to the dictionary
        cp = Board()
        self.states_dic[cp] = (0, [0, 0])
        #the trace of our exploration
        self.history = []

    def save(self, dic_filename, attempts_txt) :
        numpy.save(dic_filename, self.states_dic)
        numpy.save(attempts_txt, str(self.total_attempts))


    def load(self, dic_filename, attempts_txt) :
        if os.path.isfile(dic_filename) and os.path.isfile(attempts_txt):
            self.states_dic = numpy.load(file = dic_filename, allow_pickle = True).item()
            self.total_attempts = int(numpy.load(attempts_txt).item())



    def mcts_training(self, given_state, times) :
        for i in range(times) :
            self.selection(given_state)
            self.expansion()
            result = self.simulation()
            self.back_propagation(result)
            self.total_attempts += 1
            '''
            if (i + 1) % 10 == 0 :
                print(self.states_dic[given_state][WINNING_RATE])
            '''

    def best_choice(self, given_state) :
        if given_state.check_game_result() != 0 :
            return None
        legal_moves = given_state.possible_choices()
        legal_states_dic = {}

        for move in legal_moves :
            cp = copy.deepcopy(given_state)
            cp.play(move[0], move[1])
            legal_states_dic[cp] = move
        
        childs = legal_states_dic.keys()
        if len(childs) != 0:
            best_child =  copy.deepcopy(self.ucb1(childs))
            return (best_child, legal_states_dic[best_child])
        else :
            return None


    def possible_states(self, given_state) :
        #set of legal moves
        legal_moves = given_state.possible_choices()
        #init set of legal states by taking legal moves
        legal_states = set()
        for move in legal_moves :
            cp = copy.deepcopy(given_state)
            cp.play(move[0], move[1])
            legal_states.add(cp)
        return legal_states


    def selection(self, given_state) :
        #new begining, init the current state and its parent to the root
        self.current_state = copy.deepcopy(given_state)

        #add given state to the dictionary(tree)
        if self.current_state not in self.states_dic :
            res = self.current_state.check_game_result()
            if res == 0 :
                self.states_dic[copy.deepcopy(given_state)] = (res, [0, 0])
            else :
                self.states_dic[copy.deepcopy(given_state)] = (res, None)

        #clear the trace
        self.history = []
        
        #explore the tree until reaching ends or meeting a new node
        while (self.current_state in self.states_dic) and (self.current_state.check_game_result() == 0):

            #choose the "best" choice given by ucb1
            #track the path of exploration
            self.history.append(copy.deepcopy(self.current_state))
            temp = self.best_choice(self.current_state)
            if temp != None :
                best_state, best_move = temp
            else :
                break

            self.current_state = copy.deepcopy(best_state)
            self.current_move = best_move

        #reached an unexplored state, selection is over, now time to expansion


    def expansion(self) :
        #add the new node to the trace
        cp = copy.deepcopy(self.current_state)
        self.history.append(copy.deepcopy(self.current_state))

        #add the new node to the dictionary
        res = cp.check_game_result()
        if res != 0 :
            self.states_dic[cp] = (res, None)
        else :
            if cp not in self.states_dic :
                self.states_dic[cp] = (0, [0, 0])

    
    def simulation(self) :
        '''
        simulate_state = copy.deepcopy(self.current_state)
        copy_history = copy.deepcopy(self.history)

        while len(copy_history < 4) :
            copy_history = [Board(),] + copy_history

        copy_history


        value = NET(batch)
        if value < 1.5 :
            return 1
        elif value = 1.5 :
            return 3
        elif value > 1.5 :
            return 2
        else :
            print("Something wrong")
            return "wrong"
        '''





        simulate_state = copy.deepcopy(self.current_state)
        while simulate_state.check_game_result() == 0 :
            move = random.choice(list(simulate_state.possible_choices()))
            
            simulate_state.play(move[0], move[1])
            
        res = simulate_state.check_game_result()
        return res


    def back_propagation(self, result) :
        for state in self.history :
            if self.states_dic[state][STATUS] == 0 :
                self.states_dic[state][WINNING_RATE][1] += 1
        #if black wins    
        if result == 1 :
            for state in self.history :
                if self.states_dic[state][STATUS] == 0 and state.player == BLACK :
                    self.states_dic[state][WINNING_RATE][0] += 1
        #if white wins
        elif result == 2 :
            for state in self.history :
                if self.states_dic[state][STATUS] == 0 and state.player == WHITE :
                    self.states_dic[state][WINNING_RATE][0] += 1
        #else, nothing to do

        

    def ucb1(self, child_states) :
        max_ucb = -1000000
        chosen = None

        for state in child_states :
            res = state.check_game_result()
            #if reached an end state
            if res != 0 :
                if res == 3 :
                    upper_bound = 0.55
                elif res == 2 :
                    if state.player == WHITE :
                        upper_bound = 10000
                    elif state.player == BLACK :
                        upper_bound = -10000
                elif res == 1 :
                    if state.player == WHITE :
                        upper_bound = -10000
                    elif state.player == BLACK :
                        upper_bound = 10000
            #if reached a state not in dictionary
            elif state not in self.states_dic :
                attempts = 0
                mean = 0.5
                upper_bound = mean + math.sqrt(2 * math.log(self.total_attempts) / (1 + attempts))
            else :
                attempts = self.states_dic[state][WINNING_RATE][1]
                wins = self.states_dic[state][WINNING_RATE][0]
                if attempts != 0:
                    mean = wins / attempts
                else :
                    mean = 0.5
                upper_bound = mean + math.sqrt(2 * math.log(self.total_attempts) / (1 + attempts))

            if upper_bound >= max_ucb :
                max_ucb = upper_bound
                chosen = state
        
        return chosen








