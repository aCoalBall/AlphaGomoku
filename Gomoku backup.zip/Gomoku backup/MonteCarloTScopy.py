from gomoku import *
import random
import copy
import math

BLACK = 1
WHITE = 2

STATUS = 0
WINNING_RATE = 1
ALL_MOVES = 2

class Board :

    def __init__(self, map = None, step = None, player = None) :
        """constructor"""
        if map == None :
            self.game_map = [[0 for y in range(15)] for x in range(15)] #the chessboard
        else :
            self.game_map = map
        
        if step == None :
            self.current_step = 0 #the current step
        else :
            self.current_step = step

        if player == None :
            self.player = BLACK
        else :
            self.player = player

    def __hash__(self) :
        return hash(tuple(item for sublist in self.game_map for item in sublist) + (self.player,))
    
    def __eq__(self, other) :
        return tuple(item for sublist in self.game_map for item in sublist) == \
            tuple(item for sublist in other.game_map for item in sublist) and \
                self.player == other.player


    def play(self, pos_x, pos_y) :
        if 0 <= pos_x <= 14 and 0 <= pos_y <= 14 :
            if self.player == BLACK :
                if self.game_map[pos_x][pos_y] == 0:
                    self.game_map[pos_x][pos_y] = 1
                        
                    self.player = WHITE
                    self.current_step += 1
                    return
            elif self.player == WHITE :
                if self.game_map[pos_x][pos_y] == 0:
                    self.game_map[pos_x][pos_y] = 2

                    self.player = BLACK
                    self.current_step += 1
                    return
        else :
            return
    
    def possible_choices(self) :
        if self.check_game_result() == 0 :
            legal = set()
            xs = []
            ys = []
            for x in range(15) :
                for y in range(15) :
                    if self.game_map[x][y] != 0 :
                        xs.append(x)
                        ys.append(y)
            if len(xs) == 0 :
                legal.add((7,7))
                return legal
            minx = max(min(xs) - 3, 0)
            maxx = min(max(xs) + 3, 14)
            miny = max(min(ys) - 3, 0)
            maxy = min(max(ys) + 3, 14)
            for x in range(minx, maxx + 1) :
                for y in range(miny, maxy + 1) :
                    if self.game_map[x][y] == 0 :
                        legal.add((x,y))
            return legal
        else :
            return set()


    def check_game_result(self) :
        """return 0 if the game keeps going
           return 1 if the BLACK wins
           return 2 if the WHITE wins
           return 3 if it's a draw"""
        #1 check horizontal direction
        for x in range(11) :
            for y in range(11) :
                if self.game_map[x+4][y] == 1 and self.game_map[x+3][y] == 1 and self.game_map[x+2][y] == 1 and self.game_map[x+1][y] == 1 and self.game_map[x][y] == 1 :
                    return 1
                if self.game_map[x+4][y] == 2 and self.game_map[x+3][y] == 2 and self.game_map[x+2][y] == 2 and self.game_map[x+1][y] == 2 and self.game_map[x][y] == 2 :
                    return 2

        #2 check vertical direction
        for x in range(11) :
            for y in range(11) :
                if self.game_map[x][y] == 1 and self.game_map[x][y+1] == 1 and self.game_map[x][y+2] == 1 and self.game_map[x][y+3] == 1 and self.game_map[x][y+4] == 1 :
                    return 1
                if self.game_map[x][y] == 2 and self.game_map[x][y+1] == 2 and self.game_map[x][y+2] == 2 and self.game_map[x][y+3] == 2 and self.game_map[x][y+4] == 2 :
                    return 2

        #3 check from upper-left to lower-right
        for x in range(11) :
            for y in range(11) :
                if self.game_map[x][y+4] == 1 and self.game_map[x+1][y+3] == 1 and self.game_map[x+2][y+2] == 1 and self.game_map[x+3][y+1] == 1 and self.game_map[x+4][y] == 1 :
                    return 1
                if self.game_map[x][y+4] == 2 and self.game_map[x+1][y+3] == 2 and self.game_map[x+2][y+2] == 2 and self.game_map[x+3][y+1] == 2 and self.game_map[x+4][y] == 2 :
                    return 2

        #4 check from upper-right to lower-left
        for x in range(11) :
            for y in range(11) :
                if self.game_map[x+4][y+4] == 1 and self.game_map[x+3][y+3] == 1 and self.game_map[x+2][y+2] == 1 and self.game_map[x+1][y+1] == 1 and self.game_map[x][y] == 1 :
                    return 1
                if self.game_map[x+4][y+4] == 2 and self.game_map[x+3][y+3] == 2 and self.game_map[x+2][y+2] == 2 and self.game_map[x+1][y+1] == 2 and self.game_map[x][y] == 2 :
                    return 2
        #5 check if it's a draw
        for x in range(15) :
            for y in range(15) :
                if self.game_map[x][y] == 0 :
                    return 0

        return 3



class MonteCarlo :


    def __init__(self) :

        
        self.current_state = Board()

        #total exploration times
        self.total_attempts = 1

        #for each state, record its status, and its winning rate 
        # in the form (status, [win, all])
        self.states_dic = {}
        
        #add the root state to the dictionary
        cp = Board()
        self.states_dic[cp] = (0, [0, 0], cp.possible_choices())

        #the trace of our exploration
        self.history = []

    def mcts_training(self, given_state, times) :
        for i in range(times) :
            self.selection(given_state)
            self.expansion()
            result = self.simulation()
            self.back_propagation(result)
            self.total_attempts += 1

            if (i + 1) % 10 == 0 :
                print(self.states_dic[given_state][WINNING_RATE])

    def best_choice(self, given_state) :
        if given_state.check_game_result() != 0 :
            return None
        legal_moves = given_state.possible_choices()
        legal_states_dic = {}

        for move in legal_moves :
            cp = copy.deepcopy(given_state)
            cp.play(move[0], move[1])
            legal_states_dic[cp] = move
        
        childs = self.possible_states(given_state)
        if len(childs):
            best_child =  copy.deepcopy(self.ucb1(childs))
        else :
            return None

        return (best_child, legal_states_dic[best_child])

    def possible_states(self, given_state) :
        #set of legal moves
        legal_moves = given_state.possible_choices()
        #init set of legal states by taking legal moves
        legal_states = set()
        for move in legal_moves :
            cp = copy.deepcopy(given_state)
            cp.play(move[0], move[1])
            legal_states.add(cp)
        return legal_states


    def selection(self, given_state) :
        #new begining, init the current state and its parent to the root
        self.current_state = copy.deepcopy(given_state)

        #add given state to the dictionary(tree)
        if self.current_state not in self.states_dic :
            res = self.current_state.check_game_result()
            if res == 0 :
                self.states_dic[copy.deepcopy(given_state)] = (res, [0, 0])
            else :
                self.states_dic[copy.deepcopy(given_state)] = (res, None)


        #clear the trace
        self.history = []
        
        
        #explore the tree until reaching ends or meeting a new node
        while (self.current_state in self.states_dic) and (self.current_state.check_game_result() == 0):

            #choose the "best" choice given by ucb1
            legal_states = self.possible_states(self.current_state)
            #track the path of exploration
            self.history.append(copy.deepcopy(self.current_state))

            self.current_state = copy.deepcopy(self.ucb1(legal_states))
        

        #reached an unexplored state, selection is over, now time to expansion

    def expansion(self) :

        #add the new node to the trace
        cp = copy.deepcopy(self.current_state)
        self.history.append(copy.deepcopy(self.current_state))

        #add the new node to the dictionary
        res = cp.check_game_result()
        if res != 0 :
            self.states_dic[cp] = (res, None, None)
        
        else :
            if cp not in self.states_dic :
                self.states_dic[cp] = (0, [0, 0], cp.possible_choices())
        
        pass
    
    def simulation(self) :

        simulate_state = copy.deepcopy(self.current_state)
        while simulate_state.check_game_result() == 0 :
            move = random.choice(list(simulate_state.possible_choices()))
            
            simulate_state.play(move[0], move[1])
            
        res = simulate_state.check_game_result()
        return res

    def back_propagation(self, result) :


        for state in self.history :
            if self.states_dic[state][STATUS] == 0 :
                self.states_dic[state][WINNING_RATE][1] += 1
        #if black wins    
        if result == 1 :
            for state in self.history :
                if self.states_dic[state][STATUS] == 0 and state.player == BLACK :
                    self.states_dic[state][WINNING_RATE][0] += 1
        #if white wins
        elif result == 2 :
            for state in self.history :
                if self.states_dic[state][STATUS] == 0 and state.player == WHITE :
                    self.states_dic[state][WINNING_RATE][0] += 1
        #else, nothing to do

        

    def ucb1(self, child_states) :
        max_ucb = 0
        chosen = None


        for state in child_states :
            res = state.check_game_result()
            #if reached an end state
            if res != 0 :
                if res == 3 :
                    upper_bound = 0.55
                elif res == 2 :
                    if state.player == WHITE :
                        upper_bound = -10000
                    elif state.player == BLACK :
                        upper_bound = 10000
                elif res == 1 :
                    if state.player == WHITE :
                        upper_bound = 10000
                    elif state.player == BLACK :
                        upper_bound = -10000
            #if reached a state not in dictionary
            elif state not in self.states_dic :
                attempts = 0
                mean = 0.5
                upper_bound = mean + math.sqrt(2 * math.log(self.total_attempts) / (1 + attempts))
            else :
                attempts = self.states_dic[state][WINNING_RATE][1]
                wins = self.states_dic[state][WINNING_RATE][0]
                if attempts != 0:
                    mean = 1 - (wins / attempts)
                else :
                    mean = 0.5
                upper_bound = mean + math.sqrt(2 * math.log(self.total_attempts) / (1 + attempts))

            if upper_bound >= max_ucb :
                max_ucb = upper_bound
                chosen = state
        
        return chosen

class Selfplay :
    def __init__(self):
        self.explorer = MonteCarlo()

    def training(self):
        #reset
        game = Board()
        game_history = []
        move_history = []

        while game.check_game_result() == 0 :
            game_history.append(copy.deepcopy(game))
            self.explorer.mcts_training(game, 20)
            game , move = self.explorer.best_choice(game)
            move_history.append(move)
        
        player = []
        for i in range(len(move_history)) :
            if (i + 1) % 2 == 1 :
                player.append(BLACK)
            else :
                player.append(WHITE)

        
        return (game.check_game_result(),
            game_history, 
            move_history,
            player)
    pass

def main() :
    #mc = MonteCarlo()
    #mc.mcts_training(Board(), 1000)
    #mc.mcts_training(Board(), 100)

    sp = Selfplay()
    res, states, moves, player = sp.training()
    print(res)
    print(moves)
    print(player)


if __name__ == '__main__' :
    main()



