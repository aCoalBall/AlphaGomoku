import random
import copy
import math
import os
import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
import torchvision.models as models

from gomoku import *
from MonteCarloTS import MonteCarlo
from BoardForMCTS import Board
from GomokuNet import NeuralNetwork
from GomokuNet import NET


class Selfplay :
    def __init__(self):
        self.explorer = MonteCarlo()
        self.explorer.load('mcts_dic.npy', 'mcts_attempts.npy')

        self.learning_rate = 1e-3
        self.loss_mse = nn.MSELoss()
        self.optimizer = torch.optim.SGD(NET.parameters(), lr = self.learning_rate)

    def play_one_game(self):
        #reset
        game = Board()
        game_history = []
        move_history = []

        while game.check_game_result() == 0 :
            game_history.append(copy.deepcopy(game))
            self.explorer.mcts_training(game, 1)
            game , move = self.explorer.best_choice(game)
            print(move)
            move_history.append(move)
        
        player = []
        for i in range(len(move_history)) :
            if (i + 1) % 2 == 1 :
                player.append(BLACK)
            else :
                player.append(WHITE)

        self.explorer.save('mcts_dic.npy', 'mcts_attempts.npy')

        
        return (game.check_game_result(),
            game_history, 
            move_history,
            player)
    
    def get_net_standard(self, result, game_history) :
        if result == 3 :
            result = 1.5
        result = [result]
        results = []
        for state in game_history :
            results.append(result)

        results = torch.tensor(results, dtype=torch.float)
        return results
                

    
    def get_net_input(self, game_history, move_history, player):

        batch_size = len(game_history)
        game_history = [Board(), Board(), Board()] + game_history


        batch = []
        for i in range(batch_size) :
            state1 = game_history[i].game_map
            state2 = game_history[i+1].game_map
            state3 = game_history[i+2].game_map
            state4 = game_history[i+3].game_map

            if player[i] == 1 :
                player_state = [[1 for y in range(15)] for x in range(15)]
            elif player[i] == 2 :
                player_state = [[2 for y in range(15)] for x in range(15)]

            move_state = [[0 for y in range(15)] for x in range(15)]
            x,y = move_history[i]
            move_state[x][y] = player[i]

            sample = [state1, state2, state3, state4, player_state, move_state]
            batch.append(sample)

        batch = torch.tensor(batch, dtype=torch.float)
        return batch
        

    def optimize(self, batch, standard) :
        pred = NET(batch)
        loss = self.loss_mse(pred, standard) 

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()



        
    
    def save_net(self, filename) :
        torch.save(NET.state_dict(), 'net_weights.pth')

def main() :
    '''
    os.chdir(os.path.dirname(__file__))
    mc = MonteCarlo()
    mc.mcts_training(Board(), 20)
    mc.save('mcts_dic.npy', 'mcts_attempts.npy')
    print(mc.total_attempts)

    mc = MonteCarlo()
    mc.load('mcts_dic.npy', 'mcts_attempts.npy')
    mc.mcts_training(Board(), 20)
    print(mc.total_attempts)
    '''

    
    sp = Selfplay()
    res, states, moves, player = sp.play_one_game()
    print(res)
    print(len(moves))
    print(len(player))

    batch = sp.get_net_input(states, moves, player)
    standard = sp.get_net_standard(res, states)
    sp.optimize(batch, standard)
    print('Good Job!')
    
    
if __name__ == '__main__' :
    main()